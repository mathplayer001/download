@echo off
title workwork driver install
net session >"%TEMP%\ww_chk.tmp" 2>&1
if errorlevel 1 goto ELEVATE
goto INSTALL

:ELEVATE
echo.
echo Requesting administrator rights...
echo Please click YES in the popup window.
echo.
powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
exit /b

:INSTALL
cd /d "%~dp0"
echo.
echo Installing Interception driver, please wait...
echo.
install-interception.exe /install
echo.
echo ================================================
echo   DONE. Please RESTART the computer,
echo   then run workwork.exe
echo ================================================
echo.
pause
