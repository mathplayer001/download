@echo off
chcp 65001 >nul
title workwork 驱动安装

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo 正在请求管理员权限，请在弹出的窗口点"是"...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"

echo.
echo 正在安装 Interception 驱动，请稍候...
install-interception.exe /install
echo.
echo ==============================================
echo   安装完成！请【重启电脑】，然后双击 workwork.exe
echo ==============================================
echo.
pause
